package com.aguarealista.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Tela da engrenagem: níveis de gráfico e opções. */
public class TelaConfig extends Screen {
    private static final int[] INTENS = {25, 50, 75, 100, 150, 200, 250};
    private final Screen pai;

    public TelaConfig(Screen pai) {
        super(Component.literal("⚙ Água Realista"));
        this.pai = pai;
    }

    private static String onOff(boolean v) { return v ? "§aLIGADO" : "§cDESLIGADO"; }

    @Override
    protected void init() {
        Config c = Config.I;
        int w = 200, h = 20, x = this.width / 2 - w / 2, y = this.height / 2 - 100;

        Button nivel = Button.builder(Component.literal(""), b -> {
            c.nivel = (c.nivel + 1) % Config.NIVEIS.length;
            b.setMessage(Component.literal("Nível de gráfico: §e" + Config.nivel().nome()));
        }).bounds(x, y, w, h).build();
        nivel.setMessage(Component.literal("Nível de gráfico: §e" + Config.nivel().nome()));
        this.addRenderableWidget(nivel);
        y += 24;

        this.addRenderableWidget(alternar(x, y, w, h, "Efeitos: ", () -> c.ligado, v -> c.ligado = v)); y += 24;
        this.addRenderableWidget(alternar(x, y, w, h, "Ondas e espuma: ", () -> c.ondas, v -> c.ondas = v)); y += 24;
        this.addRenderableWidget(alternar(x, y, w, h, "Cachoeiras: ", () -> c.quedas, v -> c.quedas = v)); y += 24;
        this.addRenderableWidget(alternar(x, y, w, h, "Respingos: ", () -> c.respingos, v -> c.respingos = v)); y += 24;
        this.addRenderableWidget(alternar(x, y, w, h, "Névoa: ", () -> c.nevoa, v -> c.nevoa = v)); y += 24;
        this.addRenderableWidget(alternar(x, y, w, h, "Bolhas: ", () -> c.bolhas, v -> c.bolhas = v)); y += 24;

        Button intens = Button.builder(Component.literal(""), b -> {
            int i = 0;
            for (int k = 0; k < INTENS.length; k++) if (INTENS[k] == c.intens) i = k;
            c.intens = INTENS[(i + 1) % INTENS.length];
            b.setMessage(Component.literal("Intensidade: §e" + c.intens + "%"));
        }).bounds(x, y, w, h).build();
        intens.setMessage(Component.literal("Intensidade: §e" + c.intens + "%"));
        this.addRenderableWidget(intens);
        y += 30;

        this.addRenderableWidget(Button.builder(Component.literal("Pronto"), b -> this.onClose()).bounds(x, y, w, h).build());
    }

    private interface Getter { boolean get(); }
    private interface Setter { void set(boolean v); }

    private Button alternar(int x, int y, int w, int h, String rotulo, Getter g, Setter s) {
        Button b = Button.builder(Component.literal(rotulo + onOff(g.get())), btn -> {
            s.set(!g.get());
            btn.setMessage(Component.literal(rotulo + onOff(g.get())));
        }).bounds(x, y, w, h).build();
        return b;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        super.render(g, mouseX, mouseY, partial);
        g.drawCenteredString(this.font, this.title, this.width / 2, this.height / 2 - 125, 0xFFFFFF);
    }

    @Override
    public void onClose() {
        Config.salvar();
        if (this.minecraft != null) this.minecraft.setScreen(this.pai);
    }
}
