package com.aguarealista.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import com.aguarealista.ModParticulas;
import com.aguarealista.Tipo;
import com.aguarealista.sim.Fluido;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** Água física: bola e jorro de partículas simulados no cliente. */
public final class FluidoCliente {
    private static final class Jorro {
        double x, y, z, dx, dy, dz;
        int resta, taxa, capa;
    }

    private final Fluido sim = new Fluido();
    private final ArrayList<Jorro> jorros = new ArrayList<>();
    private final HashMap<Long, Byte> cache = new HashMap<>();
    private final BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
    private final Random rnd = new Random();
    private ClientLevel nivelAnt;

    public void limpar() {
        sim.limpar();
        jorros.clear();
    }

    public void bola(LocalPlayer p) {
        Config.Nivel n = Config.nivel();
        Vec3 h = p.getEyePosition();
        Vec3 d = p.getLookAngle();
        sim.bola(h.x + d.x * 1.8, h.y + d.y * 1.8, h.z + d.z * 1.8, n.bola(),
                d.x * 0.32, d.y * 0.32 + 0.04, d.z * 0.32, n.capa());
    }

    public void jorro(LocalPlayer p) {
        Config.Nivel n = Config.nivel();
        Vec3 h = p.getEyePosition();
        Vec3 d = p.getLookAngle();
        Jorro j = new Jorro();
        j.x = h.x + d.x; j.y = h.y + d.y - 0.25; j.z = h.z + d.z;
        j.dx = d.x; j.dy = d.y; j.dz = d.z;
        j.resta = 70;
        j.taxa = Math.max(2, Math.round(n.bola() / 18f));
        j.capa = n.capa();
        jorros.add(j);
    }

    /** 0 = livre, 1 = sólido, 2 = água do jogo */
    private byte tipo(ClientLevel lvl, int x, int y, int z) {
        long k = BlockPos.asLong(x, y, z);
        Byte c = cache.get(k);
        if (c != null) return c;
        mp.set(x, y, z);
        BlockState s = lvl.getBlockState(mp);
        byte r;
        if (s.getFluidState().is(FluidTags.WATER)) r = 2;
        else if (s.isAir()) r = 0;
        else r = s.getCollisionShape(lvl, mp).isEmpty() ? (byte) 0 : (byte) 1;
        cache.put(k, r);
        return r;
    }

    public void tick(Minecraft mc) {
        final ClientLevel lvl = mc.level;
        if (lvl == null) { limpar(); return; }
        if (lvl != nivelAnt) { limpar(); nivelAnt = lvl; }
        cache.clear();

        for (int i = jorros.size() - 1; i >= 0; i--) {
            Jorro e = jorros.get(i);
            for (int k = 0; k < e.taxa; k++) {
                sim.add(e.x + (rnd.nextDouble() - 0.5) * 0.15, e.y + (rnd.nextDouble() - 0.5) * 0.15, e.z + (rnd.nextDouble() - 0.5) * 0.15,
                        e.dx * 0.28 + (rnd.nextDouble() - 0.5) * 0.03, e.dy * 0.28 + (rnd.nextDouble() - 0.5) * 0.03,
                        e.dz * 0.28 + (rnd.nextDouble() - 0.5) * 0.03, e.capa);
            }
            if (--e.resta <= 0) jorros.remove(i);
        }
        if (sim.ps.isEmpty()) return;

        sim.passo(new Fluido.Mundo() {
            @Override public boolean solido(int x, int y, int z) { return tipo(lvl, x, y, z) == 1; }
            @Override public boolean agua(int x, int y, int z) { return tipo(lvl, x, y, z) == 2; }
        });

        SimpleParticleType fl = ModParticulas.get(Tipo.FLUIDO);
        for (Fluido.P q : sim.ps) {
            double sp = Math.sqrt(q.vx * q.vx + q.vy * q.vy + q.vz * q.vz);
            lvl.addParticle(fl, q.x, q.y, q.z, Math.min(1.0, sp * 3.5), 0, 0);
        }

        int n = 0;
        for (Fluido.Evento ev : sim.eventos) {
            if (n++ > 6) break;
            for (int k = 0; k < 4; k++) {
                lvl.addParticle(ModParticulas.get(Tipo.GOTA), ev.x, ev.y + 0.2, ev.z,
                        (rnd.nextDouble() - 0.5) * 0.12, 0.10 + rnd.nextDouble() * 0.12 + ev.v * 0.2, (rnd.nextDouble() - 0.5) * 0.12);
            }
            lvl.addParticle(ModParticulas.get(Tipo.ESPUMA), ev.x, ev.y + 0.1, ev.z, 0, 1.0, 0);
        }
    }
}
