package com.aguarealista.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import com.aguarealista.ModParticulas;
import com.aguarealista.Tipo;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Ondas, espuma, marolas na costa, cachoeiras e respingos em volta do jogador. */
public final class EfeitosAmbiente {
    private static final class Sup { int x, y, z; float h; int dx, dz; }
    private static final class Queda { int x, z, top, base; boolean piscina; }
    private static final class Dados {
        final ArrayList<Sup> surf = new ArrayList<>();
        final ArrayList<Sup> costa = new ArrayList<>();
        final ArrayList<Queda> quedas = new ArrayList<>();
    }

    private final Random rnd = new Random();
    private final BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
    private final HashMap<Integer, Boolean> dentroAnt = new HashMap<>();
    private final HashMap<Integer, Long> tAnt = new HashMap<>();
    private List<Entity> ents = new ArrayList<>();
    private Dados cache, nova;
    private int cursor, ox, oy, oz;
    private ClientLevel nivelAnt;

    private void spawn(ClientLevel l, Tipo t, double x, double y, double z, double dx, double dy, double dz) {
        l.addParticle(ModParticulas.get(t), x, y, z, dx, dy, dz);
    }

    private static boolean agua(BlockState s) { return s.getFluidState().is(FluidTags.WATER); }

    public void tick(Minecraft mc, long t) {
        Config cfg = Config.I;
        if (!cfg.ligado) return;
        ClientLevel lvl = mc.level;
        LocalPlayer p = mc.player;
        if (lvl == null || p == null) return;
        if (lvl != nivelAnt) { nivelAnt = lvl; cache = null; nova = null; cursor = 0; dentroAnt.clear(); tAnt.clear(); }
        Config.Nivel N = Config.nivel();
        varrer(lvl, p, N);
        efeitosAgua(lvl, p, cfg, N, t);
        efeitosEntidades(lvl, p, cfg, N, t);
    }

    // ---------- varredura incremental ----------
    private void varrer(ClientLevel lvl, LocalPlayer p, Config.Nivel N) {
        int R = N.raio(), W = 2 * R + 1, total = W * W;
        if (nova == null) {
            nova = new Dados();
            ox = (int) Math.floor(p.getX()); oy = (int) Math.floor(p.getY()); oz = (int) Math.floor(p.getZ());
            cursor = 0;
        }
        int yTop = oy + 10, yBot = oy - 14;
        for (int k = 0; k < N.colunas() && cursor < total; cursor++) {
            int dx = (cursor % W) - R, dz = (cursor / W) - R;
            if (dx * dx + dz * dz > R * R) continue;
            k++;
            varrerColuna(lvl, ox + dx, oz + dz, yTop, yBot, nova);
        }
        if (cursor >= total) { cache = nova; nova = null; }
    }

    private void varrerColuna(ClientLevel lvl, int x, int z, int yTop, int yBot, Dados out) {
        boolean prevCai = false;
        int topo = 0, baixo = 0;
        for (int y = yTop; y >= yBot; y--) {
            BlockState b = lvl.getBlockState(mp.set(x, y, z));
            FluidState fs = b.getFluidState();
            boolean agua = fs.is(FluidTags.WATER);
            boolean cai = agua && fs.hasProperty(FlowingFluid.FALLING) && fs.getValue(FlowingFluid.FALLING);
            if (cai) {
                if (!prevCai) topo = y;
                baixo = y;
            } else {
                if (prevCai) { Queda q = new Queda(); q.x = x; q.z = z; q.top = topo; q.base = baixo; q.piscina = agua; out.quedas.add(q); }
                if (agua && out.surf.size() < 4000 && lvl.getBlockState(mp.set(x, y + 1, z)).isAir()) {
                    Sup s = new Sup();
                    s.x = x; s.y = y; s.z = z; s.h = fs.getOwnHeight();
                    if (fs.isSource()) {
                        int[][] viz = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
                        for (int[] v : viz) {
                            BlockState nb = lvl.getBlockState(mp.set(x + v[0], y, z + v[1]));
                            if (!nb.isAir() && !agua(nb)) { s.dx = v[0]; s.dz = v[1]; out.costa.add(s); break; }
                        }
                    }
                    out.surf.add(s);
                }
            }
            prevCai = cai;
        }
        if (prevCai) { Queda q = new Queda(); q.x = x; q.z = z; q.top = topo; q.base = baixo; q.piscina = false; out.quedas.add(q); }
    }

    // ---------- ondas, costa, cachoeiras ----------
    private void efeitosAgua(ClientLevel lvl, LocalPlayer p, Config cfg, Config.Nivel N, long t) {
        Dados c = cache;
        if (c == null) return;
        double I = (cfg.intens / 100.0) * N.dens();
        double R2 = (double) N.raio() * N.raio();
        double px = p.getX(), pz = p.getZ();

        if (cfg.ondas && !c.surf.isEmpty()) {
            int n = (int) Math.floor(N.ondas() * (cfg.intens / 100.0) + rnd.nextDouble());
            for (int i = 0; i < n; i++) {
                Sup s = c.surf.get(rnd.nextInt(c.surf.size()));
                if ((s.x - px) * (s.x - px) + (s.z - pz) * (s.z - pz) > R2) continue;
                double f1 = s.x * 0.42 + s.z * 0.27 - t * 0.05;
                double f2 = -s.x * 0.21 + s.z * 0.5 - t * 0.035;
                double cr = Math.sin(f1) * 0.6 + Math.sin(f2) * 0.4;
                if (cr > 0.7) {
                    spawn(lvl, Tipo.ESPUMA, s.x + rnd.nextDouble(), s.y + s.h + 0.03, s.z + rnd.nextDouble(),
                            1.5, 0.8 + rnd.nextDouble() * 0.8, 1.0);
                }
            }
        }

        if (cfg.ondas && !c.costa.isEmpty()) {
            int n = (int) Math.floor(N.ondas() * 0.5 * (cfg.intens / 100.0) + rnd.nextDouble());
            for (int i = 0; i < n; i++) {
                Sup s = c.costa.get(rnd.nextInt(c.costa.size()));
                if ((s.x - px) * (s.x - px) + (s.z - pz) * (s.z - pz) > R2) continue;
                double surto = (Math.sin(t * 0.07 + (s.x + s.z) * 0.3) + 1) / 2;
                if (surto > 0.78) {
                    spawn(lvl, Tipo.ESPUMA, s.x + 0.5 + s.dx * 0.35 + (rnd.nextDouble() - 0.5) * 0.6, s.y + s.h + 0.04,
                            s.z + 0.5 + s.dz * 0.35 + (rnd.nextDouble() - 0.5) * 0.6, s.dx * 0.8, 1.0 + rnd.nextDouble() * 0.8, s.dz * 0.8);
                }
            }
        }

        if (cfg.quedas && !c.quedas.isEmpty()) {
            int n = Math.min(N.quedas(), c.quedas.size());
            for (int i = 0; i < n; i++) {
                Queda q = c.quedas.get(rnd.nextInt(c.quedas.size()));
                if ((q.x - px) * (q.x - px) + (q.z - pz) * (q.z - pz) > R2) continue;
                int alt = q.top - q.base + 1;
                double cx = q.x + 0.5, cz = q.z + 0.5;
                int nf = Math.max(1, (int) Math.round(Math.min(alt, 8) * 0.5 * I));
                for (int k = 0; k < nf; k++) {
                    spawn(lvl, Tipo.GOTA, q.x + 0.15 + rnd.nextDouble() * 0.7, q.base + rnd.nextDouble() * alt, q.z + 0.15 + rnd.nextDouble() * 0.7,
                            0, -0.25 - rnd.nextDouble() * 0.15, 0);
                }
                if (rnd.nextDouble() < 0.5) {
                    int g = (int) Math.ceil(2 * I);
                    for (int k = 0; k < g; k++) {
                        spawn(lvl, Tipo.GOTA, cx, q.top + 0.7, cz, (rnd.nextDouble() - 0.5) * 0.12, 0.05, (rnd.nextDouble() - 0.5) * 0.12);
                    }
                }
                if (cfg.nevoa) {
                    int m = (int) Math.ceil(2 * I);
                    for (int k = 0; k < m; k++) {
                        spawn(lvl, Tipo.NEBLINA, cx + (rnd.nextDouble() - 0.5) * 0.8, q.base + 0.3, cz + (rnd.nextDouble() - 0.5) * 0.8,
                                0, Math.min(1 + alt * 0.12, 2.2), 0);
                    }
                }
                if (cfg.respingos) {
                    int g = (int) Math.ceil(Math.min(alt, 6) * 1.5 * I);
                    double v = 0.12 + Math.min(alt, 10) * 0.012;
                    for (int k = 0; k < g; k++) {
                        spawn(lvl, Tipo.GOTA, cx, q.base + 0.4, cz, (rnd.nextDouble() - 0.5) * v * 2, v * (0.8 + rnd.nextDouble()), (rnd.nextDouble() - 0.5) * v * 2);
                    }
                }
                if (q.piscina && cfg.ondas && rnd.nextDouble() < 0.4) {
                    spawn(lvl, Tipo.ESPUMA, cx + (rnd.nextDouble() - 0.5) * 2, q.base + 0.9, cz + (rnd.nextDouble() - 0.5) * 2,
                            (rnd.nextDouble() - 0.5), 1.0 + rnd.nextDouble(), (rnd.nextDouble() - 0.5));
                }
            }
        }
    }

    // ---------- entidades: splash, rastro, bolhas ----------
    private void efeitosEntidades(ClientLevel lvl, LocalPlayer p, Config cfg, Config.Nivel N, long t) {
        if (t % 4 == 0 || ents.isEmpty()) {
            double r = N.raio();
            List<Entity> l = lvl.getEntities((Entity) null, new AABB(p.getX() - r, p.getY() - r, p.getZ() - r, p.getX() + r, p.getY() + r, p.getZ() + r));
            ents = new ArrayList<>();
            ents.add(p);
            for (Entity e : l) {
                if (e == p) continue;
                if (ents.size() > N.maxEnt()) break;
                ents.add(e);
            }
        }
        double I = (cfg.intens / 100.0) * N.dens();
        for (Entity e : ents) {
            if (e.isRemoved()) continue;
            int id = e.getId();
            boolean dentro = e.isInWater();
            boolean ant = dentroAnt.getOrDefault(id, false);
            long tUlt = tAnt.getOrDefault(id, -100L);
            Vec3 v = e.getDeltaMovement();
            double vh = Math.sqrt(v.x * v.x + v.z * v.z);
            double vel = Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
            double ys = Math.floor(e.getY()) + 0.9;
            double x = e.getX(), z = e.getZ();

            if (dentro && !ant && t - tUlt > 10 && cfg.respingos) {
                int g = (int) Math.ceil((6 + vel * 40) * I);
                for (int k = 0; k < g; k++) {
                    spawn(lvl, Tipo.GOTA, x, ys, z, (rnd.nextDouble() - 0.5) * 0.2, 0.12 + rnd.nextDouble() * 0.15 + vel * 0.25, (rnd.nextDouble() - 0.5) * 0.2);
                }
                if (cfg.nevoa && vel > 0.3) {
                    for (int k = 0; k < (int) Math.ceil(3 * I); k++) spawn(lvl, Tipo.NEBLINA, x, ys, z, 0, 1.0, 0);
                }
                if (cfg.ondas) {
                    for (int k = 0; k < (int) Math.ceil(3 * I); k++) {
                        spawn(lvl, Tipo.ESPUMA, x + (rnd.nextDouble() - 0.5), ys, z + (rnd.nextDouble() - 0.5), 0, 1.4, 0);
                    }
                }
            }
            if (dentro) {
                if (cfg.ondas && vh > 0.04 && t % 2 == 0) {
                    spawn(lvl, Tipo.ESPUMA, x - v.x * 4, ys, z - v.z * 4, -v.x * 2, 0.6 + vh * 3, -v.z * 2);
                }
                if (cfg.respingos && vh > 0.2 && t % 2 == 0) {
                    int g = (int) Math.ceil(3 * I);
                    for (int k = 0; k < g; k++) {
                        spawn(lvl, Tipo.GOTA, x, ys, z, v.x * 0.6 + (rnd.nextDouble() - 0.5) * 0.1, 0.10 + rnd.nextDouble() * 0.1, v.z * 0.6 + (rnd.nextDouble() - 0.5) * 0.1);
                    }
                }
                if (cfg.bolhas && t % 6 == 0 && e.isUnderWater() && (vel > 0.03 || rnd.nextDouble() < 0.2)) {
                    int g = (int) Math.ceil(2 * I);
                    for (int k = 0; k < g; k++) {
                        spawn(lvl, Tipo.BOLHA, x - v.x * 3 + (rnd.nextDouble() - 0.5) * 0.3, e.getEyeY(), z - v.z * 3 + (rnd.nextDouble() - 0.5) * 0.3, 0, 0, 0);
                    }
                }
            }
            dentroAnt.put(id, dentro);
            if (dentro || ant) tAnt.put(id, t);
        }
        if (t % 400 == 0) { dentroAnt.clear(); tAnt.clear(); }
    }
}
