package com.aguarealista.client;

import com.aguarealista.AguaRealista;
import com.aguarealista.ModParticulas;
import com.aguarealista.Tipo;
import com.mojang.blaze3d.platform.InputConstants;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.particle.v1.FabricSpriteProvider;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.item.ItemStack;

public class AguaRealistaClient implements ClientModInitializer {
    private static final FluidoCliente FLUIDO = new FluidoCliente();
    private static final EfeitosAmbiente AMBIENTE = new EfeitosAmbiente();

    @Override
    public void onInitializeClient() {
        Config.carregar();

        // partículas de água
        for (Tipo t : Tipo.values()) {
            final Tipo tipo = t;
            ParticleFactoryRegistry.getInstance().register(ModParticulas.get(t),
                    new ParticleFactoryRegistry.PendingParticleFactory<SimpleParticleType>() {
                        @Override
                        public ParticleProvider<SimpleParticleType> create(FabricSpriteProvider sprites) {
                            return (type, level, x, y, z, dx, dy, dz) -> new AguaParticula(level, x, y, z, dx, dy, dz, sprites, tipo);
                        }
                    });
        }

        // tecla G abre a engrenagem
        KeyMapping tecla = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.aguarealista.config", InputConstants.Type.KEYSYM, InputConstants.KEY_G, "key.categories.aguarealista"));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (tecla.consumeClick()) {
                mc.setScreen(new TelaConfig(mc.screen));
            }
            if (mc.level == null || mc.isPaused()) return;
            long t = mc.level.getGameTime();
            AMBIENTE.tick(mc, t);
            FLUIDO.tick(mc);
        });

        // botão ⚙ no menu de pausa
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof PauseScreen) {
                Screens.getButtons(screen).add(
                        Button.builder(Component.literal("⚙"), b -> client.setScreen(new TelaConfig(screen)))
                                .bounds(w - 26, 6, 20, 20).build());
            }
        });

        // itens: engrenagem abre a tela, balde joga água física (agachar = jorro)
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack st = player.getItemInHand(hand);
            if (!world.isClientSide) return InteractionResultHolder.pass(st);
            Minecraft mc = Minecraft.getInstance();
            if (st.is(AguaRealista.ENGRENAGEM)) {
                mc.setScreen(new TelaConfig(null));
                return InteractionResultHolder.success(st);
            }
            if (st.is(AguaRealista.BALDE) && mc.player != null) {
                if (player.isShiftKeyDown()) FLUIDO.jorro(mc.player); else FLUIDO.bola(mc.player);
                return InteractionResultHolder.success(st);
            }
            return InteractionResultHolder.pass(st);
        });
    }
}
