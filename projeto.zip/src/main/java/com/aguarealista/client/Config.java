package com.aguarealista.client;

import java.nio.file.Files;
import java.nio.file.Path;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import net.fabricmc.loader.api.FabricLoader;

/** Configurações salvas em config/aguarealista.json */
public final class Config {
    public int nivel = 1;            // 0 Baixo, 1 Médio, 2 Alto, 3 Ultra
    public boolean ligado = true;
    public boolean ondas = true;
    public boolean quedas = true;
    public boolean respingos = true;
    public boolean nevoa = true;
    public boolean bolhas = true;
    public int intens = 100;         // 25..250

    public record Nivel(String nome, int raio, int colunas, double dens, int maxEnt, int ondas, int quedas, int bola, int capa) {}

    public static final Nivel[] NIVEIS = {
        new Nivel("Baixo", 10, 10, 0.35, 4, 2, 4, 60, 100),
        new Nivel("Médio", 16, 20, 0.70, 10, 4, 8, 110, 200),
        new Nivel("Alto", 22, 32, 1.10, 20, 7, 14, 180, 320),
        new Nivel("Ultra", 30, 48, 1.70, 36, 12, 24, 280, 480),
    };

    public static Config I = new Config();

    public static Nivel nivel() {
        int n = Math.max(0, Math.min(NIVEIS.length - 1, I.nivel));
        return NIVEIS[n];
    }

    private static Path arquivo() {
        return FabricLoader.getInstance().getConfigDir().resolve("aguarealista.json");
    }

    public static void carregar() {
        try {
            Path a = arquivo();
            if (Files.exists(a)) {
                Config c = new Gson().fromJson(Files.readString(a), Config.class);
                if (c != null) I = c;
            }
        } catch (Exception e) {
            I = new Config();
        }
    }

    public static void salvar() {
        try {
            Files.writeString(arquivo(), new GsonBuilder().setPrettyPrinting().create().toJson(I));
        } catch (Exception ignored) {
        }
    }
}
