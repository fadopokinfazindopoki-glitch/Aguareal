package com.aguarealista;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class AguaRealista implements ModInitializer {
    public static final String ID = "aguarealista";

    public static final Item BALDE = new Item(new Item.Properties().stacksTo(1));
    public static final Item ENGRENAGEM = new Item(new Item.Properties().stacksTo(1));

    @Override
    public void onInitialize() {
        Registry.register(BuiltInRegistries.ITEM, ResourceLocation.fromNamespaceAndPath(ID, "balde"), BALDE);
        Registry.register(BuiltInRegistries.ITEM, ResourceLocation.fromNamespaceAndPath(ID, "engrenagem"), ENGRENAGEM);
        ModParticulas.registrar();

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> {
            entries.accept(BALDE);
            entries.accept(ENGRENAGEM);
        });

        // dá os itens ao entrar no mundo (se o jogador ainda não tiver)
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer p = handler.player;
            darSeFalta(p, BALDE);
            darSeFalta(p, ENGRENAGEM);
        });
    }

    private static void darSeFalta(ServerPlayer p, Item item) {
        for (ItemStack s : p.getInventory().items) {
            if (s.is(item)) return;
        }
        p.getInventory().add(new ItemStack(item));
    }
}
