package com.aguarealista;

public enum Tipo { FLUIDO, ESPUMA, NEBLINA, GOTA, BOLHA }
