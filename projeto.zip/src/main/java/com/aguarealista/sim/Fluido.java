package com.aguarealista.sim;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;

/** Simulação de fluido por partículas (SPH simplificado). Java puro, sem Minecraft. */
public final class Fluido {
    public interface Mundo {
        boolean solido(int x, int y, int z);
        boolean agua(int x, int y, int z);
    }

    public static final class P {
        public double x, y, z, vx, vy, vz;
        int idade, rep, cx, cy, cz;
        double fx, fy, fz, dvx, dvy, dvz;
    }

    public static final class Evento {
        public final double x, y, z, v;
        Evento(double x, double y, double z, double v) { this.x = x; this.y = y; this.z = z; this.v = v; }
    }

    private static final double R0 = 0.29, H = 0.58, H2 = H * H, GRAV = 0.055, VMAX = 0.5;

    public final ArrayList<P> ps = new ArrayList<>();
    public final ArrayList<Evento> eventos = new ArrayList<>();
    private final Random rnd = new Random();
    private final HashMap<Long, int[]> grade = new HashMap<>();

    public void add(double x, double y, double z, double vx, double vy, double vz, int capa) {
        P p = new P();
        p.x = x; p.y = y; p.z = z; p.vx = vx; p.vy = vy; p.vz = vz;
        ps.add(p);
        while (capa > 0 && ps.size() > capa) ps.remove(0);
    }

    public void bola(double cx, double cy, double cz, int n, double vx, double vy, double vz, int capa) {
        double r = Math.cbrt((n * R0 * R0 * R0) / 4.19) * 1.25;
        for (int i = 0; i < n; i++) {
            double x, y, z;
            do { x = rnd.nextDouble() * 2 - 1; y = rnd.nextDouble() * 2 - 1; z = rnd.nextDouble() * 2 - 1; } while (x * x + y * y + z * z > 1);
            add(cx + x * r, cy + y * r, cz + z * r,
                    vx + (rnd.nextDouble() - 0.5) * 0.04, vy + (rnd.nextDouble() - 0.5) * 0.04, vz + (rnd.nextDouble() - 0.5) * 0.04, capa);
        }
    }

    public void limpar() { ps.clear(); eventos.clear(); }

    private static long chave(int a, int b, int c) {
        return ((long) (a & 0x1FFFFF) << 42) | ((long) (b & 0x1FFFFF) << 21) | (long) (c & 0x1FFFFF);
    }

    private static int fl(double v) { return (int) Math.floor(v); }

    public void passo(Mundo mundo) {
        eventos.clear();
        int n = ps.size();
        if (n == 0) return;

        grade.clear();
        for (int i = 0; i < n; i++) {
            P p = ps.get(i);
            p.fx = 0; p.fy = 0; p.fz = 0; p.dvx = 0; p.dvy = 0; p.dvz = 0;
            p.cx = fl(p.x / H); p.cy = fl(p.y / H); p.cz = fl(p.z / H);
            long k = chave(p.cx, p.cy, p.cz);
            int[] l = grade.get(k);
            if (l == null) {
                l = new int[8];
                l[0] = 1; l[1] = i;
                grade.put(k, l);
            } else {
                if (l[0] + 1 >= l.length) l = Arrays.copyOf(l, l.length * 2);
                l[0]++;
                l[l[0]] = i;
                grade.put(k, l);
            }
        }

        for (int i = 0; i < n; i++) {
            P a = ps.get(i);
            for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) {
                int[] l = grade.get(chave(a.cx + dx, a.cy + dy, a.cz + dz));
                if (l == null) continue;
                for (int m = 1; m <= l[0]; m++) {
                    int j = l[m];
                    if (j <= i) continue;
                    P b = ps.get(j);
                    double ex = a.x - b.x, ey = a.y - b.y, ez = a.z - b.z;
                    double d2 = ex * ex + ey * ey + ez * ez;
                    if (d2 >= H2 || d2 < 1e-8) continue;
                    double d = Math.sqrt(d2), w = 1 - d / H;
                    double f = d < R0 ? 0.02 * (R0 - d) / R0 : -0.003 * (d - R0) / (H - R0);
                    double ux = ex / d, uy = ey / d, uz = ez / d;
                    a.fx += ux * f; a.fy += uy * f; a.fz += uz * f;
                    b.fx -= ux * f; b.fy -= uy * f; b.fz -= uz * f;
                    double vx = (b.vx - a.vx) * 0.3 * w, vy = (b.vy - a.vy) * 0.3 * w, vz = (b.vz - a.vz) * 0.3 * w;
                    a.dvx += vx; a.dvy += vy; a.dvz += vz;
                    b.dvx -= vx; b.dvy -= vy; b.dvz -= vz;
                }
            }
        }

        for (int i = n - 1; i >= 0; i--) {
            P p = ps.get(i);
            p.idade++;
            p.vx += p.fx + p.dvx; p.vy += p.fy + p.dvy - GRAV; p.vz += p.fz + p.dvz;
            p.vx *= 0.975; p.vy *= 0.985; p.vz *= 0.975;
            double sp = Math.sqrt(p.vx * p.vx + p.vy * p.vy + p.vz * p.vz);
            if (sp > VMAX) { double k = VMAX / sp; p.vx *= k; p.vy *= k; p.vz *= k; }

            int guard = 0;
            while (mundo.solido(fl(p.x), fl(p.y), fl(p.z)) && guard++ < 6) p.y += 0.25;

            double nx = p.x + p.vx;
            if (mundo.solido(fl(nx), fl(p.y), fl(p.z))) p.vx *= -0.3; else p.x = nx;
            double nz = p.z + p.vz;
            if (mundo.solido(fl(p.x), fl(p.y), fl(nz))) p.vz *= -0.3; else p.z = nz;
            double ny = p.y + p.vy;
            if (mundo.solido(fl(p.x), fl(ny), fl(p.z))) {
                if (p.vy < 0) { p.vy *= -0.1; p.vx *= 0.75; p.vz *= 0.75; } else p.vy *= -0.2;
            } else p.y = ny;

            double v2 = p.vx * p.vx + p.vy * p.vy + p.vz * p.vz;
            if (v2 < 0.0004) p.rep++; else p.rep = Math.max(0, p.rep - 2);

            if (mundo.agua(fl(p.x), fl(p.y), fl(p.z))) {
                if (Math.sqrt(v2) > 0.12) eventos.add(new Evento(p.x, p.y, p.z, Math.sqrt(v2)));
                ps.remove(i);
                continue;
            }
            if (p.idade > 500 && p.rep > 60 && rnd.nextDouble() < 0.004) { ps.remove(i); continue; }
            if (p.idade > 2400 || p.y < -70) ps.remove(i);
        }
    }
}
